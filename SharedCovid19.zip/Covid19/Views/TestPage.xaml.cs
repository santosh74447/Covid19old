﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Covid19.Views
{
    public partial class TestPage : ContentPage
    {
        public TestPage()
        {
            InitializeComponent();
        }
    }
}
