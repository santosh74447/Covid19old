﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Covid19.Views
{
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }
    }
}
