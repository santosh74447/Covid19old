﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Runtime.CompilerServices;
using Covid19.Models;
using Newtonsoft.Json;
using Xamarin.Forms;

namespace Covid19.ViewModels
{
    public class CountryViewModel : INotifyPropertyChanged
    {
        public INavigation Navigation { get; set; }
        public static ObservableCollection<CountryModel> _scollectionSkills;
        public CountryViewModel(INavigation _navigation)
        {
            Navigation = _navigation;
        }

        public CountryViewModel()
        {
        }

        public async void GetSkillsData()
        {
            using (var client = new HttpClient())
            {
                // send a GET request  
                var uri = "https://corona.lmao.ninja/countries?sort=cases";
                var result = await client.GetStringAsync(uri);
                var SkillsList = JsonConvert.DeserializeObject<List<CountryModel>>(result);
                collectionSkills = new ObservableCollection<CountryModel>(SkillsList);
                _scollectionSkills = collectionSkills;
                IsRefreshing = false;
            }
        }
        public Command RefreshData
        {
            get
            {
                return new Command(() =>
                {
                    GetSkillsData();
                });
            }
        }


        bool _isRefreshing;
        public bool IsRefreshing
        {
            get
            {
                return _isRefreshing;
            }
            set
            {
                _isRefreshing = value;
                OnPropertyChanged();
            }
        }
        CountryModel _selectedSkills;
        public CountryModel SelectedSkills
        {
            get
            {
                return _selectedSkills;
            }
            set
            {
                _selectedSkills = value;
                if (value != null)
                {
                     Navigation.PushAsync(new MainPage(SelectedSkills));
                }
                OnPropertyChanged();
            }
        }

        ObservableCollection<CountryModel> _collectionSkills;
        public ObservableCollection<CountryModel> collectionSkills
        {
            get
            {
                return _collectionSkills;
            }
            set
            {
                _collectionSkills = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName]string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
