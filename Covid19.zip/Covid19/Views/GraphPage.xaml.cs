﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net.Http;
using Covid19.Models;
using Microcharts;
using Newtonsoft.Json;
using SkiaSharp;
using Xamarin.Forms;
using Xamarin.Essentials;
using Entry = Microcharts.Entry;

namespace Covid19.Views
{
    public partial class GraphPage : ContentPage
    {
        public GraphPage(string country)
        {
            InitializeComponent();

            GetSkillsData(country);
        }
        public async void GetSkillsData(string country)
        {
            using (var client = new HttpClient())
            {
                if (country == "USA")
                    country = "usa";
                // send a GET request  
                var uri = "https://corona.lmao.ninja/v2/historical/"+country;
                var result = await client.GetStringAsync(uri);
                result = result.Replace("}", "");
                //result = result.Substring(44, result.Length - 47).ToString();
                string[] s = result.Split(',');
                int index = 0;
                int rIndex=0;
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i].Contains("deaths"))
                    {
                        index = i;
                        break;
                    }
                }

                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i].Contains("recovered"))
                    {
                        rIndex = i;
                        break;
                    }
                }

                // char[] MyChar = { '"', '{', '}' };
                //result = result.TrimEnd(MyChar);

                // result = result.Remove('"');
                string[] date = new string[10];
                string[] value = new string[10];
                string[] deathDate = new string[10];
                string[] deatthValue = new string[10];
                string[] recoveredDate = new string[10];
                string[] recoveredValue = new string[10];
                int c = 0;
                for (int i = index - 10; i < index; i++)
                {
                    string[] m = s[i].Split(':');
                    date[c] = (m[0]);
                    value[c] = (m[1]);
                    c++;
                }
                 c = 0;
                for (int i = rIndex - 10; i < rIndex; i++)
                {
                    string[] m = s[i].Split(':');
                    deathDate[c] = (m[0]);
                    deatthValue[c] = (m[1]);
                    c++;
                }
                c = 0;
                for(int i = s.Length - 10; i < s.Length; i++)
                {
                    string[] m = s[i].Split(':');
                    recoveredDate[c] = (m[0]);
                    recoveredValue[c] = (m[1]);
                    c++;
                }

                List<Entry> entries = new List<Entry>
                {
                };
                List<Entry> deathData = new List<Entry>
                {
                };
                List<Entry> recoveredData = new List<Entry>
                {
                };
                for (int i = 0; i < date.Length; i++)
                {
                    if (i % 2 == 0)
                        entries.Add(new Entry(Convert.ToInt32(value[i]))
                        {
                            Color = SKColor.Parse("#FF1943"),
                            Label = date[i].Replace('"', ' '),
                            ValueLabel = value[i],
                        });
                    else
                        entries.Add(new Entry(Convert.ToInt32(value[i]))
                        {
                            Color = SKColor.Parse("#68B9C0"),
                            Label = date[i].Replace('"', ' '),
                            ValueLabel = value[i],
                        });
                }
                for (int i = 0; i < deathDate.Length; i++)
                {
                    if (i % 2 == 0)
                        deathData.Add(new Entry(Convert.ToInt32(deatthValue[i]))
                        {
                            Color = SKColor.Parse("#FF1943"),
                            Label = date[i].Replace('"', ' '),
                            ValueLabel = deatthValue[i],
                        });
                    else
                        deathData.Add(new Entry(Convert.ToInt32(deatthValue[i]))
                        {
                            Color = SKColor.Parse("#68B9C0"),
                            Label = deathDate[i].Replace('"', ' '),
                            ValueLabel = deatthValue[i],
                        });
                }
                for (int i = 0; i < recoveredDate.Length; i++)
                {
                    if (i % 2 == 0)
                        recoveredData.Add(new Entry(Convert.ToInt32(recoveredValue[i]))
                        {
                            Color = SKColor.Parse("#FF1943"),
                            Label = recoveredDate[i].Replace('"', ' '),
                            ValueLabel = recoveredValue[i],
                        });
                    else
                        recoveredData.Add(new Entry(Convert.ToInt32(recoveredValue[i]))
                        {
                            Color = SKColor.Parse("#68B9C0"),
                            Label = recoveredDate[i].Replace('"', ' '),
                            ValueLabel = recoveredValue[i],
                        });
                }
                Chart1.Chart = new LineChart() { Entries = entries };
                ChartDeath.Chart = new LineChart() { Entries = deathData };
                ChartRecovered.Chart = new LineChart() { Entries = recoveredData };
                //_scollectionSkills = collectionSkills;
                //IsRefreshing = false;
            }
        }
        ObservableCollection<CountryGraphModel> _collectionSkills;
        public ObservableCollection<CountryGraphModel> collectionSkills
        {
            get
            {
                return _collectionSkills;
            }
            set
            {
                _collectionSkills = value;
                OnPropertyChanged();
            }
        }

        //List<Entry> entries = new List<Entry>
        //{
        //    new Entry(200)
        //    {
        //        Color=SKColor.Parse("#FF1943"),
        //        Label ="January",
        //        ValueLabel = "200"
        //    },
        //    new Entry(400)
        //    {
        //        Color = SKColor.Parse("00BFFF"),
        //        Label = "March",
        //        ValueLabel = "400"
        //    },
        //    new Entry(-100)
        //    {
        //        Color =  SKColor.Parse("#00CED1"),
        //        Label = "Octobar",
        //        ValueLabel = "-100"
        //    },
        //    };
    }
}
