﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net.Http;
using Covid19.Models;
using Newtonsoft.Json;
using Xamarin.Forms;

namespace Covid19.Views
{
    public partial class TotalPage : ContentPage
    {
        DateTime updatedDate;
        public TotalPage()
        {
            InitializeComponent();
            Title = "Covid-19 Total Cases";
            GetSkillsData();
        }

        public async void GetSkillsData()
        {
            using (var client = new HttpClient())
            {
                // send a GET request  
                var uri = "https://corona.lmao.ninja/all";
                var result = await client.GetStringAsync(uri);
                result = "[" + result + "]";
                var SkillsList = JsonConvert.DeserializeObject<List<CountryModel>>(result);


               // string s = string.Format("{0,###,###}", SkillsList[0].cases.ToString());

                //converting miliseconds to date
                double ticks = double.Parse(SkillsList[0].updated);
                TimeSpan time = TimeSpan.FromMilliseconds(ticks);
                 updatedDate = new DateTime(1970, 1, 1) + time;

                lblUpdatedDate.Text = "Data as of " + updatedDate.ToString();
                lblTotalCases.Text = "Total Cases: " + SkillsList[0].cases.ToString();
                lblTotalDeath.Text = "Toal Death Cases:  " + SkillsList[0].deaths;
                lblActiveCases.Text = "Total Active Cases: "+ SkillsList[0].active;
                lblTotalRecovered.Text = "Recovered Cases: "+ SkillsList[0].recovered;
                lblTodayCases.Text = "Today Cases: " + SkillsList[0].todayCases;
                lblTodayDeath.Text = "Today Deaths: " + SkillsList[0].todayDeaths;
                lblAffectedCountry.Text = "Affected Country: " + SkillsList[0].affectedCountries;
            }
        }

        void btnSource_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new AboutPage());
        }
        void btnCountry_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new CountryView(updatedDate));
        }
    }
}
