﻿using System;
using System.Collections.Generic;
using System.Linq;
using Covid19.ViewModels;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace Covid19.Views
{
    public partial class CountryView : ContentPage
    {
        CountryViewModel countryViewModel = new CountryViewModel();
        public CountryView(DateTime updatedDate)
        {
            InitializeComponent();
            try
            {
                SkillsListView.HeightRequest = DeviceDisplay.MainDisplayInfo.Height;
                BindingContext = new CountryViewModel(Navigation);
            }
            catch (System.Net.Http.HttpRequestException)
            {
                Device.BeginInvokeOnMainThread(async () => {
                    await DisplayAlert("Alert", "No internet connection", "OK");
                });
            }
        }


        protected override void OnAppearing()
        {
            try
            {
                (this.BindingContext as CountryViewModel).GetSkillsData();

            }
            catch (System.Net.Http.HttpRequestException)
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await DisplayAlert("Alert", "No internet connection", "Ok");
                });

            }
        }

        void txtSearch_TextChanged(System.Object sender, Xamarin.Forms.TextChangedEventArgs e)
        {
             SkillsListView.BeginRefresh();

            if (string.IsNullOrWhiteSpace(txtSearch.Text))
                SkillsListView.ItemsSource = CountryViewModel._scollectionSkills;
            else
                SkillsListView.ItemsSource = CountryViewModel._scollectionSkills.Where(i => i.country.Contains(txtSearch.Text));
            
            SkillsListView.EndRefresh();
        }
    }
}
