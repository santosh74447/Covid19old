﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Covid19.Models;
using Covid19.Views;
using Xamarin.Forms;

namespace Covid19
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        string country;
        public MainPage(CountryModel SelectedSkills)
        {
            InitializeComponent();
            Title = SelectedSkills.country.ToUpper();
            country = SelectedSkills.country;
            lblTodayCases.Text = "New Cases: " + SelectedSkills.todayCases;
            lblTodayDeath.Text = "New Deaths: " + SelectedSkills.todayDeaths;
            lblTotalCases.Text = "Total Cases: " + SelectedSkills.cases;
            lblTotalRecovered.Text = "Total Recovered: " + SelectedSkills.recovered;
            lblTotalDeath.Text = "Total Death: " + SelectedSkills.deaths;
            lblActiveCases.Text = "Active Cases: " + SelectedSkills.active;
            lblCriticalCases.Text = "Critical Cases: " + SelectedSkills.critical;
            lblCasesPerMillion.Text = "New Cases Per One Million: " + SelectedSkills.casesPerOneMillion;
            lblDeathPerMillion.Text = "Death Per One Million: " + SelectedSkills.deathsPerOneMillion;


            //converting miliseconds to date
            double ticks = double.Parse(SelectedSkills.updated);
            TimeSpan time = TimeSpan.FromMilliseconds(ticks);
            DateTime updatedDate = new DateTime(1970, 1, 1) + time;

            lblUpdatedDate.Text = "Data as of "+ updatedDate.ToString();
        }

        void btnSource_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new AboutPage());
        }

        void btnHistory_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new GraphPage(country));
        }
    }
}
